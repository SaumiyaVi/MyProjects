package testngMaven;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import org.openqa.selenium.support.ui.Select; 
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import java.lang.*;

public class TestNGCurrencyConverter {
	WebDriver driver;

	@BeforeClass
	public void testSetup()
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\ASUS\\eclipse-workspace\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.manage().window().maximize();

	}
	
	@BeforeMethod
	public void openBrowser()
	{
	driver.get("https://www.xe.com/currencyconverter/");
	driver.findElement(By.xpath("//button[text()='Customize']")).click();
	driver.findElement(By.xpath("//button[text()='Confirm']")).click();
	System.out.println("We are currently on the following URL" +driver.getCurrentUrl());
	}
	
	@Test(description="This method validates the conversion from dollar to euro")
	@Parameters ({"FromCurrency","ToCurrency"})
	public void ConvertTheCurrencyMethod(String FromCurrency, String ToCurrency ) throws InterruptedException
	{
		Thread.sleep(3000);
		String amountToBeConverted = "100";
		WebElement amount = driver.findElement(By.id("amount"));
		amount.sendKeys(amountToBeConverted);
		driver.findElement(By.id("midmarketFromCurrency")).sendKeys(FromCurrency);
		driver.findElement(By.xpath("//*[@id='midmarketFromCurrency-option-0']")).click(); 	   
		Thread.sleep(3000);
		driver.findElement(By.id("midmarketToCurrency")).sendKeys(ToCurrency);
		driver.findElement(By.xpath("//*[@id='midmarketToCurrency-option-0']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Convert']")).click();
		Thread.sleep(3000);
		WebElement element = driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/section/div[2]/div/main/form/div[2]/div[3]/div[1]/div[1]/p[1]"));
		String conversionRate = element.getAttribute("innerHTML");
		conversionRate = conversionRate.split(" ")[3];
		double calculatedValue= Double.parseDouble(conversionRate) * Double.parseDouble(amountToBeConverted);
		String expectedValue = String.valueOf(calculatedValue);
		expectedValue = expectedValue.split("\\.")[0].concat(".");
		String convertedValue=driver.findElement(By.cssSelector("p.result__BigRate-sc-1bsijpp-1.iGrAod")).getAttribute("innerHTML");
		String actualValue = StringUtils.remove(convertedValue, "<span class=\"faded-digits\">").replace("</span>", " ");
		System.out.println(actualValue);
		System.out.println(expectedValue);
		System.out.println(conversionRate);
		Assert.assertTrue(actualValue.contains(expectedValue),"Incorrect currency conversion");

	}
	
	@AfterClass
	public void afterClass()
	{
	driver.quit();
	}
}
